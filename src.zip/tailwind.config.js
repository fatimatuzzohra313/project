/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#f3f1ff',
          100: '#ebe5ff',
          200: '#d9ceff',
          300: '#bea6ff',
          400: '#9f75ff',
          500: '#8445ff',
          600: '#7422f7',
          700: '#6312de',
          800: '#5211b5',
          900: '#450e94',
          950: '#290066',
        },
        secondary: {
          50: '#eefbfd',
          100: '#d5f3fa',
          200: '#b1e8f5',
          300: '#7bd7ed',
          400: '#3bbee0',
          500: '#1ea2c7',
          600: '#1981a8',
          700: '#196889',
          800: '#1b5671',
          900: '#1b4860',
          950: '#0e2e41',
        },
        accent: {
          50: '#fff1f2',
          100: '#ffe4e8',
          200: '#fecdd6',
          300: '#fda4b4',
          400: '#fb6f8c',
          500: '#f33a6a',
          600: '#de1b50',
          700: '#be0e3e',
          800: '#9f1239',
          900: '#851436',
          950: '#4c0519',
        },
      },
      fontFamily: {
        sans: ['"Inter"', 'sans-serif'],
        display: ['"Poppins"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      boxShadow: {
        'glow': '0 0 15px rgba(132, 69, 255, 0.5)',
        'glow-accent': '0 0 15px rgba(243, 58, 106, 0.5)',
      },
      keyframes: {
        shimmer: {
          '0%': { backgroundPosition: '-500px 0' },
          '100%': { backgroundPosition: '500px 0' },
        },
      },
      animation: {
        shimmer: 'shimmer 2.5s infinite linear',
      },
    },
  },
  plugins: [],
};